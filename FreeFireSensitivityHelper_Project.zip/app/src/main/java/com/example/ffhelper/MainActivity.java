package com.example.ffhelper;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.content.Intent;
import android.provider.Settings;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView text(String value, int size) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(0xFF172033);
        t.setPadding(0, 12, 0, 12);
        return t;
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(28, 36, 28, 28);
        page.setBackgroundColor(0xFFF4F7FB);

        TextView title = text("FF Sensitivity Helper", 26);
        title.setTypeface(null, Typeface.BOLD);
        page.addView(title);

        page.addView(text("Phone detected: " + Build.MANUFACTURER + " " + Build.MODEL, 17));
        page.addView(text("Starter sensitivity suggestions\nGeneral: 90\nRed Dot: 85\n2x Scope: 80\n4x Scope: 75\nSniper Scope: 50\nFree Look: 70", 19));
        page.addView(text("These are starting points only. Adjust them gradually in the game's own settings; this app does not change game settings or control aiming.", 15));

        Button settings = new Button(this);
        settings.setText("Open phone settings");
        settings.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_SETTINGS)));
        page.addView(settings);

        TextView note = text("Aim practice: use the training area inside Free Fire. Keep the same settings for a few matches before deciding whether to adjust them.", 16);
        page.addView(note);

        scroll.addView(page);
        setContentView(scroll);
    }
}
